<?php
ini_set('display_errors',1);
require_once('smarty-4.2.1/libs/Smarty.class.php');
$smarty = new Smarty();
$smarty->template_dir='views';
$smarty->compile_dir='tmp';

// getting detail of all users
include("connection.php");
$sql="select * from user";
$result = mysqli_query($conn,$sql);

//fetch all the arrays
$n=mysqli_fetch_all($result, MYSQLI_ASSOC);


//assigning the title to title card
$smarty->assign('title','Display Using - Smarty');

// assigning the arrays to the users
$smarty->assign('users',$n);


$smarty->display('display.tpl');
?>