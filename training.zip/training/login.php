<?php include ('server.php');


session_start();

if(isset($_SESSION['username'])){
  header("location:index.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=, initial-scale=1.0">
<title>admin dashboard</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Raleway:wght@200&display=swap" rel="stylesheet"> 
<style>

.login_panel{
margin-top:10%;
display: flex;
flex-direction: column;
justify-content: center;
align-items: center;
}
body{
font-family: 'Raleway', sans-serif;
}
input{
border-radius:10px;
margin:10px 10px;
padding:10px;
border:none;

}
form{
    background-color:grey;
display: flex;
flex-direction:column;
align-items:center;
width:60%;
justify-content:center;

}

</style>
</head>
<body>
<div class="login_panel">
<p>admin login</p>
<form action="login.php"  method="post">
<input type="text" name="name" id="name" placeholder="admin username">
<input type="password" name="pass" id="pass" placeholder="admin password">
<input type="submit" name="login" value="submit" >
</form>
</div>
</body>
</html>