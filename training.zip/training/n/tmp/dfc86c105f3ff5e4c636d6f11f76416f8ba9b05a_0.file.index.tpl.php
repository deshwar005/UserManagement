<?php
/* Smarty version 4.2.1, created on 2022-10-05 16:15:48
  from '/home/gunadeshwar/web/training/n/views/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_633d605c821b77_34512995',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'dfc86c105f3ff5e4c636d6f11f76416f8ba9b05a' => 
    array (
      0 => '/home/gunadeshwar/web/training/n/views/index.tpl',
      1 => 1664966746,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_633d605c821b77_34512995 (Smarty_Internal_Template $_smarty_tpl) {
echo '<?php'; ?>

 require('server.php');

 session_start();

if(!isset($_SESSION['username'])){
  header("location:login.php");
}
<?php echo '?>'; ?>


<html>
<head>
<title>Info</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">
  <?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"><?php echo '</script'; ?>
>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Raleway:wght@200&display=swap" rel="stylesheet"> 
</head>
<body>

  <div class="nav pt-4 ">
      <ul class="list-inline">
      <li  class="list-inline-item">
          <a class="text-decoration-none text-capitalize text-dark"href="index.php"><?php echo '<?php'; ?>
 echo $_SESSION['username']<?php echo '?>'; ?>
</a></li>
          <li class="list-inline-item">
          <a class="text-decoration-none 	text-danger"href="logout.php">logout</a></li>
        </ul>
    </div>


<table class="table table-dark table-hovertable-striped" width="100%" >
        <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Number</th>
            <th>Email</th>
            <th>Password</th>
            <th>Action</th>
            <th>DELETE</th>
        </tr>
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['users']->value, 'user');
$_smarty_tpl->tpl_vars['user']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['user']->value) {
$_smarty_tpl->tpl_vars['user']->do_else = false;
?>
         <tr>
        <td> <?php echo $_smarty_tpl->tpl_vars['user']->value['id'];?>
</td>
         <td> <?php echo $_smarty_tpl->tpl_vars['user']->value['name'];?>
</td>
         <td> <?php echo $_smarty_tpl->tpl_vars['user']->value['mobile'];?>
</td>
          <td> <?php echo $_smarty_tpl->tpl_vars['user']->value['email'];?>
</td>
           <td> <?php echo $_smarty_tpl->tpl_vars['user']->value['pass'];?>
</td>
            <td><a class="btn btn-warning"href="edit.php">Edit</a></td>
        <td><form action="index.php" method="post">

        <input type='hidden'  name="id" value=<?php echo '<?php'; ?>
 echo $row['id']<?php echo '?>'; ?>
 
        <input class="btn btn-danger" type="submit" value='delete' name='delete'/>
        </form>
        </td>
    </tr>
    <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
     
     </table>

</body>
</html><?php }
}
