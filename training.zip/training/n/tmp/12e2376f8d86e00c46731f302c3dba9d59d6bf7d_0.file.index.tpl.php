<?php
/* Smarty version 4.2.1, created on 2022-10-05 14:26:33
  from '/home/gunadeshwar/web/new/views/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_633d46c10897d1_91503309',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '12e2376f8d86e00c46731f302c3dba9d59d6bf7d' => 
    array (
      0 => '/home/gunadeshwar/web/new/views/index.tpl',
      1 => 1664960188,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_633d46c10897d1_91503309 (Smarty_Internal_Template $_smarty_tpl) {
?><html>
<head>
<title>Info</title>
</head>
<body>

<table class="table table-dark table-hovertable-striped" width="100%" >
        <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Number</th>
            <th>Email</th>
            <th>Password</th>
            <th>Action</th>
            <th>DELETE</th>
        </tr>
         <tr>
        <td> <?php echo $_smarty_tpl->tpl_vars['name']->value;?>
</td>
        <td><?php echo $_smarty_tpl->tpl_vars['address']->value;?>
</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td> </td>
    </tr>
     
     </table>

</body>
</html><?php }
}
