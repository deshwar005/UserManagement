<?php
ini_set('display_errors',1);
require_once('smarty-4.2.1/libs/Smarty.class.php');
$smarty = new Smarty();
$smarty->template_dir='views';
$smarty->compile_dir='tmp';


include("connection.php");
$sql="select * from user";
$result = mysqli_query($conn,$sql);
$n=mysqli_fetch_all($result, MYSQLI_ASSOC);


$smarty->assign('users',$n);


$smarty->display('display.tpl');
?>