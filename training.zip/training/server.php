
<?php require('connection.php');


$username ="";
$mobile ="";
$email="";
$num=0;


//user adding
if(isset($_POST['submit'])){


$username =$_POST['name'];
if (empty($_POST["name"])) {
    $success=2;
$err = "name is required";
return;
}

if (empty($_POST["mobile"])) {
$err = "mobile is required";
$success=2;
return;
}

$mobile =$_POST['mobile'];
if (empty($_POST["email"])) {
    $success=2;
$err = "Email is required";
return;
}

$email=$_POST['email'];
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $success=2;
$err = "Invalid email format";
return;
}

$pass=md5($_POST['password']);
if(strlen($pass)<5){
    $success=2;
$err="Password should be greater than 5 character ";
return;
}
  
$success=0;

$sql="INSERT INTO user(name,mobile,email,pass) VALUES ('$username','$mobile','$email','$pass')";
if (mysqli_query($conn, $sql)) {
$success=1;
} else {
 $success=2;
 echo "ERROR IN QUERY";
}
}
















//login 

if(isset($_POST['login'])){

$username =$_POST['name'];
$pass=$_POST['pass'];
$sql = "SELECT * from admin where username='$username' AND password='$pass'";
$row=mysqli_query($conn,$sql);
$result=mysqli_fetch_assoc($row);
if($result){
    session_start();
$_SESSION['username']=$result['username'];

header("location:index.php");
}else{
echo ($sql);  
}
}



//edit  
if(isset($_POST['editid'])){
 
 $num=$_POST['id'];
}


if(isset($_POST['edit'])){


  
    
$id =$_POST['id'];
$username =$_POST['name'];
$mobile =$_POST['mobile'];
$email=$_POST['email'];
$pass=md5($_POST['password']);
$sql="select * from user where id ='$id'";

$row=mysqli_query($conn,$sql);
if($row){
$result= mysqli_fetch_assoc($row);
if($result['id']===$id){
$update = "UPDATE user 
SET name='$username' ,
mobile ='$mobile',
email='$email' ,
pass='$pass' 
where id = '$id' ";
$result = mysqli_query($conn,$update);
if($result){
$success=1;
}else{
 echo "unsuccessfull";
}
}
} else{
echo("not found");
}
}









//delete 

if(isset($_POST['delete'])){
$id= $_POST['id'];
$sql = "DELETE FROM user WHERE id='$id' ";
$row=mysqli_query($conn,$sql);
if($row){
    $success=1;
}
}
?>



