<?php
$conn = new mysqli("127.0.0.1","root","gft#123","users");
if ($conn->connect_error){
 echo("connection failed");
 die("Connection failed: "
 . $conn->connect_error);
}
?>
