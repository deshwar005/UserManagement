
<?php
 require('server.php');

 session_start();

if(!isset($_SESSION['username'])){
  header("location:login.php");
}
?>


 
 <!DOCTYPE html>
<html>
<head> 
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"></script>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Raleway:wght@200&display=swap" rel="stylesheet"> 

<title>form</title> 
<style>

ul{
display: flex;
justify-content: flex-end;
align-items: center;
list-style: none;
}
input{

padding:10px;
border:none;
}
form{
display: flex;
flex-direction: column;
justify-content: center;
align-items: center;



}
</style>



</head>

<body class="bg-light">
  <div class="container  ">
    
<!-- nav bar -->
<div class="nav pt-4 ">
<ul class="list-inline">
<li  class="list-inline-item">
<a class="text-decoration-none text-capitalize text-dark"href="index.php"><?php echo $_SESSION['username']?></a></li>
<li class="list-inline-item">
<a class="text-decoration-none 	text-warning"href="display.php">display</a></li>
<li class="list-inline-item">
<a class="text-decoration-none 	text-danger"href="logout.php">logout</a></li>
</ul>
</div>


<!-- validation server side -->
<div class="success1">
<?php if($success==1){?>
<div class="alert alert-success alert-dismissible fade show">
<button type="button" class="btn-close" data-bs-dismiss="alert"></button>
<strong>Success!</strong> operation performed successfully.
</div>
<?php }  else if($success==2) {?>
<div class="alert alert-danger alert-dismissible fade show">
<button type="button" class="btn-close" data-bs-dismiss="alert"></button>
<strong>failed!</strong> <?php echo $err?>.
</div>
       
  
  
<?php }?>
</div>

<h4 class=" h1  text-center   title">Add user </h4>

<!-- Getting input of user detail  -->
<form name="myForm " id="myForm" class="p-2 "  action="index.php" onsubmit="return validate() " method="post">
<input  class=" mt-4 bg-dark text-light" id="name" name="name" type="text"   placeholder="Name"/>
<input  class="  mt-4 bg-dark text-light" id="mobile"   name="mobile" type="text"   placeholder="mobile"/>
<input   class=" mt-4 bg-dark text-light " id="email"  name="email" type="text"   placeholder="email"/>
<input   class="  mt-4 bg-dark text-light" id="password"  name="password" type="password"   placeholder="password"/>
<input class="btn mt-4 btn-success" type="submit" value="submit"name="submit"/>
</form>


<!-- table displaying all the detail of users -->
<table class="table table-dark table-hovertable-striped " width="100%" >
<tr>
<th>Id</th>
<th>Name</th>
<th>Number</th>
<th>Email</th>
<th>Password</th>
<th>Action</th>
<th>DELETE</th>
</tr>

<?php
//displaying all the data from database
include("connection.php");
$sql="select * from user";
$result = mysqli_query($conn,$sql);
while($row = mysqli_fetch_assoc($result)){
?>
     
        <tr>
        <td><?php echo $row['id']  ;?>  </td>
        <td><?php echo $row['name']?></td>
        <td><?php echo $row['mobile']?></td>
        <td><?php echo $row['email']?></td>
        <td><?php echo $row['pass']?></td>
        <td>
          <!-- <a class="btn btn-warning"href="edit.php">Edit</a> -->
        
          <form action="edit.php" method="post">

        <input type='hidden'  name="id" value=<?php echo $row['id']?> />
        <input class="btn btn-warning" type="submit"  value='edit' name='editid'/>
        </form>
        </td>
        <td><form action="index.php" method="post">

        <input type='hidden'  name="id" value=<?php echo $row['id']?> />
        <input class="btn btn-danger" type="submit" value='delete' name='delete'/>
        </form>
        </td>
        </tr>
     
<?php }?>
</table>

</div>
</body>
<script>
  //form validation client-side


function validate(){
    let x = document.forms["myForm"]["name"].value;
    let y = document.forms["myForm"]["mobile"].value;
    let z=document.forms["myForm"]["email"].value;
    let g=document.forms["myForm"]["password"].value;
  if (x == "" ||x.length<3) {
    var q = y.length;
    alert("Name must be filled out properly "+g);
    return false;
  }
  if(y==""){
    alert(" mobile  must be filled out");
    return false;
  }
  if(z == ""){
    alert(" email  must be filled out");
    return false;
  }
  if(g== "" || g.length<4){
  alert(" password  must be filled  should contain a minimum of 4 character");
  return false;
  }
}
</script>

</html> 
